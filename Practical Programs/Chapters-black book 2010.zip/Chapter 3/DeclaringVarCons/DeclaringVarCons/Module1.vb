﻿Module Module1

    Sub Main()
        Const Pi = 3.14159
        Dim Radius, Area As Single
        Radius = 1
        Area = Pi * Radius * Radius
        Console.WriteLine("Area = " & Str(Area))
        Console.ReadLine()
    End Sub

End Module
