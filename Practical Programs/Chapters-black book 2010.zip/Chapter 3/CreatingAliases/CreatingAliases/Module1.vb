﻿Imports System.Console
Imports Stg = Microsoft.VisualBasic.Strings
Module Module1

    Sub Main()
        MsgBox(Stg.Right("Hello World", 5))
        ReadLine()
    End Sub

End Module
