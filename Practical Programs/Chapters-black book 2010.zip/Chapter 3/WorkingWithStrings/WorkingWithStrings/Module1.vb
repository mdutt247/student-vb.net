﻿Module Module1

    Sub Main()
        Dim strText1 As String = "this is the ultimate example of jump statements"
        Dim strText2 As String
        Dim strText3 As String
        strText2 = UCase(strText1)
        strText3 = strText1.ToUpper
        Console.WriteLine(strText2)
        Console.WriteLine(strText3)
        Console.ReadLine()

    End Sub

End Module
