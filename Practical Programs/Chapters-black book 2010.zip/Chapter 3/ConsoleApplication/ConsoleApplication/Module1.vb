﻿Option Strict Off
Imports System.Console

Module Module1

    Sub Main()
        WriteLine("Hello to the World of Visual Basic 2010")
        ReadLine()
    End Sub

End Module
