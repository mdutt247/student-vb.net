﻿Module Module1
    Public Class MainClass
        Shared Sub Main(ByVal args As String())
        End Sub
    End Class
    Public Class Amount
        Private TotalAmount, Deductions, BalanceAmount As Double 'Data members
        Public Sub Balance()
            'Method body

        End Sub
        Public Sub Debit()
            'Method body

        End Sub
        Public Sub Credit()
            'Method body

        End Sub
        Public Sub GetData()
            'Method body

        End Sub
    End Class
End Module

